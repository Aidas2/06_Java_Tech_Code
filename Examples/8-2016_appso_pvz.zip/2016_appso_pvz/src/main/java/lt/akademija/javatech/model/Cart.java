package lt.akademija.javatech.model;

import java.util.Set;

public class Cart {

    public String username;
    public Set<CartProduct> products;
}
