package lt.akademija.javatech.model;

import java.math.BigDecimal;

public class Product {

    public Long id;
    public String title;
    public String image;
    public String description;
    public BigDecimal price;
    public Long quantity;

}
