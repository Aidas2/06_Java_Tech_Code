package lt.akademija.javatech.model;

import java.math.BigDecimal;

public class NewProduct {

    public String title;
    public String image;
    public String description;
    public BigDecimal price;
    public Long quantity;
}
